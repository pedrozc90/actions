local _, ns = ...
local E = ns.E

print("Sanity Check", E)
